This is a project for Metro Railway Reservation Management System which is created using python(beginner level)

Language used : python

GUI toolkit: Tkinter

Backend library : Sqlite3,Pyqrcode

IDE used: Anaconda navigator, Jupyter notebook
